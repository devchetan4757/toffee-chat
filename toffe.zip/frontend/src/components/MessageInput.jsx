import { useRef, useState, useEffect } from "react";
import { useChatStore } from "../store/useChatStore";
import {
  Image,
  Send,
  Mic,
  Square,
  X,
  Smile,
} from "lucide-react";
import toast from "react-hot-toast";
import StickerPicker from "./StickerPicker";
import { axiosInstance } from "../lib/axios";

const blobToBase64 = (blob) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onloadend = () =>
      resolve(reader.result);

    reader.onerror = reject;

    reader.readAsDataURL(blob);
  });

const isStickerImage = (img) =>
  img?.startsWith("data:image/webp");

const MessageInput = () => {
  const {
    sendMessage,
    replyTo,
    clearReplyTo,
    sendTyping,
  } = useChatStore();

  const [text, setText] = useState("");
  const [imagePreview, setImagePreview] =
    useState(null);
  const [imageFile, setImageFile] =
    useState(null);
  const [audioBlob, setAudioBlob] =
    useState(null);
  const [isRecording, setIsRecording] =
    useState(false);
  const [showStickerPicker, setShowStickerPicker] =
    useState(false);

  // ================= CLOUDINARY STICKERS =================

  const [stickers, setStickers] = useState([]);

  const fetchStickers = async () => {
    try {
      const res = await axiosInstance.get(
        "/upload/stickers"
      );

      setStickers(res.data.stickers || []);
    } catch {
      toast.error("Failed to load stickers");
    }
  };

  // ================= POSITION / SCALE =================

  const [position, setPosition] = useState({
    top: 100,
    left: 50,
  });

  const [dragging, setDragging] =
    useState(false);

  const [scale, setScale] = useState(1);

  const inputContainerRef =
    useRef(null);

  const positionRef = useRef({
    top: 100,
    left: 50,
  });

  const scaleRef = useRef(1);

  const lastTouchDistance =
    useRef(null);

  const dragStartRef = useRef({
    x: 0,
    y: 0,
  });

  const dragRafRef = useRef(null);

  const pendingPositionRef =
    useRef(null);

  const draggingRef =
    useRef(false);

  // ================= OTHER REFS =================

  const textareaRef =
    useRef(null);

  const fileInputRef =
    useRef(null);

  const mediaRecorderRef =
    useRef(null);

  const audioChunksRef =
    useRef([]);

  // ================= IMAGE =================

  const handleImageChange = (e) => {
    const file = e.target.files?.[0];

    if (
      !file ||
      !file.type.startsWith("image/")
    ) {
      toast.error("Select a valid image");
      return;
    }

    setImageFile(file);

    const reader = new FileReader();

    reader.onloadend = () => {
      setImagePreview(reader.result);
    };

    reader.readAsDataURL(file);
  };

  // ================= AUDIO =================

  const startRecording = async () => {
    try {
      const stream =
        await navigator.mediaDevices.getUserMedia({
          audio: true,
        });

      mediaRecorderRef.current =
        new MediaRecorder(stream);

      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable =
        (e) => {
          if (e.data.size) {
            audioChunksRef.current.push(
              e.data
            );
          }
        };

      mediaRecorderRef.current.onstop =
        () => {
          const blob = new Blob(
            audioChunksRef.current,
            {
              type: "audio/webm",
            }
          );

          setAudioBlob(blob);

          stream
            .getTracks()
            .forEach((track) =>
              track.stop()
            );
        };

      mediaRecorderRef.current.start();

      setIsRecording(true);
    } catch {
      toast.error(
        "Microphone permission denied"
      );
    }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  // ================= SEND MESSAGE =================

  const handleSendMessage = async (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (
      !text.trim() &&
      !imagePreview &&
      !audioBlob
    ) {
      return;
    }

    try {
      let imageUrl = null;
      let audioUrl = null;

      // Upload real images only.
      if (
        imagePreview &&
        !isStickerImage(imagePreview)
      ) {
        const imgRes =
          await axiosInstance.post(
            "/upload/image",
            {
              image: imagePreview,
            }
          );

        imageUrl = imgRes.data.url;
      }

      // Upload audio.
      if (audioBlob) {
        const audioBase64 =
          await blobToBase64(audioBlob);

        const audioRes =
          await axiosInstance.post(
            "/upload/audio",
            {
              audio: audioBase64,
            }
          );

        audioUrl = audioRes.data.url;
      }

      // Keep the original message payload.
      await sendMessage({
        text: text.trim(),
        image: imageUrl || null,
        stickers: [],
        audio: audioUrl,

        replyTo: replyTo
          ? {
              _id: replyTo._id,
              text:
                replyTo.text || null,
              image:
                replyTo.image || null,
              audio:
                replyTo.audio || null,
              stickers:
                replyTo.stickers || null,
            }
          : null,
      });

      setText("");
      setImagePreview(null);
      setImageFile(null);
      setAudioBlob(null);

      clearReplyTo();

      requestAnimationFrame(() => {
        textareaRef.current?.focus();
      });
    } catch (err) {
      console.error(
        "Failed to send message:",
        err
      );

      toast.error(
        "Failed to send message"
      );
    }
  };

  // ================= STICKER SEND =================

  const handleStickerSend = async (
    url
  ) => {
    try {
      await sendMessage({
        text: "",
        image: null,
        audio: null,
        stickers: [url],

        replyTo: replyTo
          ? {
              _id: replyTo._id,
              text:
                replyTo.text || null,
              image:
                replyTo.image || null,
              audio:
                replyTo.audio || null,
              stickers:
                replyTo.stickers || null,
            }
          : null,
      });

      clearReplyTo();
      setShowStickerPicker(false);
    } catch {
      toast.error(
        "Failed to send sticker"
      );
    }
  };

  // ================= AUTOGROW =================

  useEffect(() => {
    if (!textareaRef.current) return;

    textareaRef.current.style.height =
      "auto";

    textareaRef.current.style.height =
      Math.min(
        textareaRef.current
          .scrollHeight,
        140
      ) + "px";
  }, [text]);

  // ================= INTERACTIVE ELEMENT CHECK =================

  /*
   * IMPORTANT:
   * Buttons, textarea, inputs etc. must NOT
   * start the drag operation.
   *
   * This prevents the Send button from becoming
   * a drag gesture on touch devices.
   */
  const isInteractiveElement = (
    target
  ) => {
    if (!target) return false;

    return Boolean(
      target.closest(
        "button, textarea, input, select, option, a, [role='button']"
      )
    );
  };

  // ================= POSITION HELPERS =================

  const clampPosition = (
    pos,
    width = 350,
    height = 140
  ) => {
    const vv =
      window.visualViewport;

    const viewportLeft =
      vv?.offsetLeft ?? 0;

    const viewportTop =
      vv?.offsetTop ?? 0;

    const vw =
      vv?.width ??
      window.innerWidth;

    const vh =
      vv?.height ??
      window.innerHeight;

    const currentScale =
      scaleRef.current;

    const maxLeft =
      viewportLeft +
      vw -
      width * currentScale;

    const maxTop =
      viewportTop +
      vh -
      height * currentScale;

    return {
      left: Math.min(
        Math.max(
          viewportLeft,
          pos.left
        ),
        Math.max(
          viewportLeft,
          maxLeft
        )
      ),

      top: Math.min(
        Math.max(
          viewportTop,
          pos.top
        ),
        Math.max(
          viewportTop,
          maxTop
        )
      ),
    };
  };

  const applyPositionImmediately = (
    nextPosition
  ) => {
    const clamped =
      clampPosition(
        nextPosition
      );

    positionRef.current =
      clamped;

    const element =
      inputContainerRef.current;

    if (!element) return;

    element.style.left =
      `${clamped.left}px`;

    element.style.top =
      `${clamped.top}px`;
  };

  // ================= SMOOTH DRAG =================

  const scheduleDragPosition = (
    nextPosition
  ) => {
    pendingPositionRef.current =
      clampPosition(
        nextPosition
      );

    if (
      dragRafRef.current !== null
    ) {
      return;
    }

    dragRafRef.current =
      requestAnimationFrame(() => {
        dragRafRef.current = null;

        const next =
          pendingPositionRef.current;

        if (!next) return;

        positionRef.current =
          next;

        const element =
          inputContainerRef.current;

        if (element) {
          element.style.left =
            `${next.left}px`;

          element.style.top =
            `${next.top}px`;
        }
      });
  };

  const commitPosition = () => {
    if (
      dragRafRef.current !== null
    ) {
      cancelAnimationFrame(
        dragRafRef.current
      );

      dragRafRef.current = null;
    }

    const next =
      pendingPositionRef.current ||
      positionRef.current;

    const clamped =
      clampPosition(next);

    positionRef.current =
      clamped;

    pendingPositionRef.current =
      null;

    setPosition(clamped);

    const element =
      inputContainerRef.current;

    if (element) {
      element.style.left =
        `${clamped.left}px`;

      element.style.top =
        `${clamped.top}px`;
    }
  };

  // ================= MOUSE DRAG =================

  const onMouseDown = (e) => {
    if (e.button !== 0) return;

    /*
     * DO NOT drag when clicking Send,
     * Mic, Image, Sticker, textarea, etc.
     */
    if (
      isInteractiveElement(
        e.target
      )
    ) {
      return;
    }

    const current =
      positionRef.current;

    draggingRef.current =
      true;

    setDragging(true);

    dragStartRef.current = {
      x:
        e.clientX -
        current.left,

      y:
        e.clientY -
        current.top,
    };
  };

  const onMouseMove = (e) => {
    if (!draggingRef.current)
      return;

    scheduleDragPosition({
      left:
        e.clientX -
        dragStartRef.current.x,

      top:
        e.clientY -
        dragStartRef.current.y,
    });
  };

  const onMouseUp = () => {
    if (!draggingRef.current)
      return;

    draggingRef.current = false;

    setDragging(false);

    commitPosition();
  };

  // ================= TOUCH HELPERS =================

  const getDistance = (
    t1,
    t2
  ) =>
    Math.hypot(
      t2.clientX -
        t1.clientX,

      t2.clientY -
        t1.clientY
    );

  // ================= TOUCH START =================

  const onTouchStart = (e) => {
    /*
     * CRITICAL FIX:
     *
     * A touch beginning on Send/Input/etc.
     * must NEVER start dragging.
     */
    if (
      isInteractiveElement(
        e.target
      )
    ) {
      return;
    }

    if (e.touches.length === 2) {
      lastTouchDistance.current =
        getDistance(
          e.touches[0],
          e.touches[1]
        );

      return;
    }

    if (
      e.touches.length !== 1
    ) {
      return;
    }

    const t = e.touches[0];

    const current =
      positionRef.current;

    draggingRef.current =
      true;

    setDragging(true);

    dragStartRef.current = {
      x:
        t.clientX -
        current.left,

      y:
        t.clientY -
        current.top,
    };
  };

  // ================= TOUCH MOVE =================

  const onTouchMove = (e) => {
    // Pinch scaling
    if (
      e.touches.length === 2 &&
      lastTouchDistance.current !==
        null
    ) {
      const newDistance =
        getDistance(
          e.touches[0],
          e.touches[1]
        );

      const diff =
        newDistance -
        lastTouchDistance.current;

      const oldScale =
        scaleRef.current;

      const newScale = Math.min(
        1.6,
        Math.max(
          0.7,
          oldScale +
            diff * 0.002
        )
      );

      scaleRef.current =
        newScale;

      setScale(newScale);

      const element =
        inputContainerRef.current;

      if (element) {
        element.style.transform =
          `scale(${newScale})`;
      }

      lastTouchDistance.current =
        newDistance;

      e.preventDefault();

      return;
    }

    // Normal dragging
    if (
      !draggingRef.current ||
      e.touches.length !== 1
    ) {
      return;
    }

    const t = e.touches[0];

    scheduleDragPosition({
      left:
        t.clientX -
        dragStartRef.current.x,

      top:
        t.clientY -
        dragStartRef.current.y,
    });

    /*
     * Only prevent browser scrolling
     * when an actual drag is happening.
     */
    e.preventDefault();
  };

  // ================= TOUCH END =================

  const onTouchEnd = () => {
    if (draggingRef.current) {
      draggingRef.current =
        false;

      setDragging(false);

      commitPosition();
    }

    lastTouchDistance.current =
      null;
  };

  // ================= WHEEL SCALE =================

  const onWheel = (e) => {
    if (!e.ctrlKey) return;

    e.preventDefault();

    const element =
      inputContainerRef.current;

    if (!element) return;

    const rect =
      element.getBoundingClientRect();

    const centerX =
      e.clientX -
      rect.left;

    const centerY =
      e.clientY -
      rect.top;

    const oldScale =
      scaleRef.current;

    const newScale = Math.min(
      1.6,
      Math.max(
        0.7,
        oldScale -
          e.deltaY * 0.001
      )
    );

    const current =
      positionRef.current;

    const offsetX =
      (centerX / oldScale) *
      (newScale -
        oldScale);

    const offsetY =
      (centerY / oldScale) *
      (newScale -
        oldScale);

    scaleRef.current =
      newScale;

    setScale(newScale);

    applyPositionImmediately({
      left:
        current.left -
        offsetX,

      top:
        current.top -
        offsetY,
    });
  };

  // ================= EVENTS =================

  useEffect(() => {
    window.addEventListener(
      "mousemove",
      onMouseMove
    );

    window.addEventListener(
      "mouseup",
      onMouseUp
    );

    window.addEventListener(
      "touchmove",
      onTouchMove,
      { passive: false }
    );

    window.addEventListener(
      "touchend",
      onTouchEnd
    );

    window.addEventListener(
      "wheel",
      onWheel,
      { passive: false }
    );

    return () => {
      window.removeEventListener(
        "mousemove",
        onMouseMove
      );

      window.removeEventListener(
        "mouseup",
        onMouseUp
      );

      window.removeEventListener(
        "touchmove",
        onTouchMove
      );

      window.removeEventListener(
        "touchend",
        onTouchEnd
      );

      window.removeEventListener(
        "wheel",
        onWheel
      );

      if (
        dragRafRef.current !== null
      ) {
        cancelAnimationFrame(
          dragRafRef.current
        );

        dragRafRef.current =
          null;
      }
    };
  });

  // ================= UI =================

  return (
    <div
      ref={inputContainerRef}
      style={{
        position: "fixed",

        top: position.top,

        left: position.left,

        zIndex: 9999,

        width: "350px",

        transform:
          `scale(${scale})`,

        transformOrigin:
          "top left",

        touchAction: "none",

        willChange: dragging
          ? "left, top, transform"
          : "auto",

        userSelect: dragging
          ? "none"
          : "auto",

        WebkitUserSelect:
          dragging
            ? "none"
            : "auto",
      }}
      onMouseDown={onMouseDown}
      onTouchStart={onTouchStart}
      className={
        dragging
          ? "cursor-grabbing"
          : "cursor-grab"
      }
    >
      <div className="flex flex-col w-full gap-1">

        {/* ================= REPLY ================= */}

        {replyTo && (
          <div className="bg-gray-200 px-3 py-1 rounded-lg flex justify-between items-center">
            <span className="text-sm truncate max-w-[80%]">
              Replying:{" "}
              {replyTo.text ||
                "Media"}
            </span>

            <button
              type="button"
              onClick={clearReplyTo}
            >
              <X size={16} />
            </button>
          </div>
        )}

        {/* ================= IMAGE PREVIEW ================= */}

        {imagePreview && (
          <div className="flex items-center gap-2 mb-1">
            <img
              src={imagePreview}
              className="w-20 h-20 rounded-md object-cover"
              alt="preview"
            />

            <button
              type="button"
              onClick={() => {
                setImagePreview(
                  null
                );

                setImageFile(null);
              }}
              className="text-red-500 text-sm"
            >
              <X size={14} />
            </button>
          </div>
        )}

        {/* ================= FORM ================= */}

        <form
          onSubmit={handleSendMessage}
          className="flex items-center gap-2 bg-base-200 rounded-full shadow-lg px-4 py-3 w-full"
        >
          {/* MIC */}

          <button
            type="button"
            onClick={
              isRecording
                ? stopRecording
                : startRecording
            }
          >
            {isRecording ? (
              <Square size={18} />
            ) : (
              <Mic size={18} />
            )}
          </button>

          {/* TEXT */}

          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => {
              setText(
                e.target.value
              );

              if (sendTyping) {
                sendTyping();
              }
            }}
            placeholder="Type a message"
            rows={1}
            className="flex-1 bg-base-100 rounded-full px-4 py-3 resize-none focus:outline-none"
          />

          {/* IMAGE INPUT */}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            hidden
            onChange={
              handleImageChange
            }
          />

          <button
            type="button"
            onClick={() =>
              fileInputRef.current?.click()
            }
          >
            <Image size={18} />
          </button>

          {/* STICKERS */}

          <button
            type="button"
            onClick={async () => {
              if (
                !showStickerPicker
              ) {
                await fetchStickers();
              }

              setShowStickerPicker(
                (p) => !p
              );
            }}
          >
            <Smile size={18} />
          </button>

          {/* SEND */}

          <button
            type="submit"
            onClick={(e) => {
              /*
               * Prevent the click from bubbling
               * into the draggable container.
               */
              e.stopPropagation();
            }}
          >
            <Send size={18} />
          </button>

          {/* STICKER PICKER */}

          {showStickerPicker && (
            <StickerPicker
              stickers={stickers}
              onStickerSelect={
                handleStickerSend
              }
              onClose={() =>
                setShowStickerPicker(
                  false
                )
              }
            />
          )}
        </form>
      </div>
    </div>
  );
};

export default MessageInput;
