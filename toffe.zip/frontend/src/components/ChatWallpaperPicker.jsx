import { useEffect, useRef, useState } from "react";
import { Image as ImageIcon, X, Loader2, Check, Upload, Ban } from "lucide-react";
import { useAuthStore } from "../store/useAuthStore";
import toast from "react-hot-toast";

const MAX_FILE_BYTES = 8 * 1024 * 1024; // 8MB, checked before we even try to resize
const MAX_DIMENSION = 1600; // downscale before sending — a wallpaper never needs full-res

// Shrinks + re-encodes an image client-side so wallpaper uploads stay
// small. Backgrounds are shown with background-size: cover, so there's
// no benefit to sending a huge original — this keeps requests small
// and well under the backend's size limit.
const resizeImage = (dataUrl) =>
  new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, MAX_DIMENSION / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);

      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      resolve(canvas.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = reject;
    img.src = dataUrl;
  });

/**
 * Small anchored panel (not a full-screen modal) for choosing the
 * chat's background image — meant to be rendered inside a
 * `position: relative` wrapper next to the button that opens it, e.g.:
 *
 *   <div className="relative">
 *     <button onClick={() => setOpen(true)}>...</button>
 *     <ChatWallpaperPicker isOpen={open} onClose={() => setOpen(false)} />
 *   </div>
 *
 * Always exactly two choices — "No wallpaper" (the plain default chat
 * background) and "Saved wallpaper" (whatever was last uploaded) —
 * plus a way to upload a new photo, which replaces the saved one and
 * switches it on right away.
 *
 * align: "left" | "right" (default "right") — which side of the
 * trigger button the panel drops down from. Pass "left" when the
 * button sits near the left edge (e.g. the chat's top strip) so the
 * panel doesn't get clipped off-screen.
 */
const ChatWallpaperPicker = ({ isOpen, onClose, align = "right" }) => {
  const { wallpaper, updateWallpaper, isUpdatingWallpaper } = useAuthStore();
  const [uploading, setUploading] = useState(false);
  const panelRef = useRef(null);

  const isActive = !!wallpaper?.active;
  const hasSaved = !!wallpaper?.hasSaved;
  const savedUrl = wallpaper?.savedUrl || null;

  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (e) => {
      if (panelRef.current && !panelRef.current.contains(e.target)) onClose();
    };

    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("touchstart", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, [isOpen, onClose]);

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file later
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      toast.error("Please choose an image file");
      return;
    }
    if (file.size > MAX_FILE_BYTES) {
      toast.error("Image must be under 8MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      setUploading(true);
      try {
        const resized = await resizeImage(reader.result);
        await updateWallpaper({ image: resized });
      } catch {
        toast.error("Couldn't process that image");
      } finally {
        setUploading(false);
      }
    };
    reader.onerror = () => toast.error("Couldn't read that file");
    reader.readAsDataURL(file);
  };

  const handleUseNone = () => {
    if (!isActive) return; // already off
    updateWallpaper({ active: false });
  };

  const handleUseSaved = () => {
    if (isActive || !hasSaved) return; // already on, or nothing to switch to
    updateWallpaper({ active: true });
  };

  if (!isOpen) return null;

  const busy = isUpdatingWallpaper || uploading;
  const sideClass = align === "left" ? "left-0" : "right-0";

  return (
    <div
      ref={panelRef}
      className={`absolute top-full ${sideClass} mt-2 w-72 max-w-[90vw] bg-base-100 rounded-xl shadow-xl border border-base-300 z-30 overflow-hidden`}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-base-300">
        <h3 className="font-semibold text-sm flex items-center gap-2">
          <ImageIcon className="w-4 h-4" />
          Chat wallpaper
        </h3>
        <button onClick={onClose} className="btn btn-ghost btn-xs btn-circle" aria-label="Close">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-3 space-y-3">
        <div className="grid grid-cols-2 gap-2">
          {/* NO WALLPAPER */}
          <button
            onClick={handleUseNone}
            disabled={busy || !isActive}
            className={`relative aspect-[3/4] rounded-lg border-2 flex flex-col items-center justify-center gap-1 text-xs font-medium transition-colors ${
              !isActive
                ? "border-primary bg-base-200"
                : "border-base-300 hover:border-primary/50"
            }`}
          >
            <Ban className="w-5 h-5 text-base-content/50" />
            No wallpaper
            {!isActive && (
              <span className="absolute top-1.5 right-1.5 bg-primary text-primary-content rounded-full p-0.5">
                <Check className="w-3 h-3" />
              </span>
            )}
          </button>

          {/* SAVED WALLPAPER */}
          <button
            onClick={handleUseSaved}
            disabled={busy || isActive || !hasSaved}
            className={`relative aspect-[3/4] rounded-lg border-2 overflow-hidden flex flex-col items-center justify-center gap-1 text-xs font-medium transition-colors bg-cover bg-center ${
              isActive
                ? "border-primary"
                : hasSaved
                ? "border-base-300 hover:border-primary/50"
                : "border-dashed border-base-300 text-base-content/40 cursor-not-allowed"
            }`}
            style={hasSaved ? { backgroundImage: `url(${savedUrl})` } : undefined}
          >
            {!hasSaved && (
              <>
                <ImageIcon className="w-5 h-5" />
                <span>No saved photo</span>
              </>
            )}
            {hasSaved && (
              <span
                className={`px-1.5 py-0.5 rounded text-[10px] ${
                  isActive ? "bg-primary text-primary-content" : "bg-black/50 text-white"
                }`}
              >
                Saved
              </span>
            )}
            {isActive && (
              <span className="absolute top-1.5 right-1.5 bg-primary text-primary-content rounded-full p-0.5">
                <Check className="w-3 h-3" />
              </span>
            )}
          </button>
        </div>

        {/* UPLOAD */}
        <label className={`btn btn-sm btn-outline w-full ${busy ? "btn-disabled" : ""}`}>
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
          {hasSaved ? "Upload a different photo" : "Upload a photo"}
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
            disabled={busy}
          />
        </label>

        <p className="text-[11px] text-base-content/50 text-center">
          Only visible on your side of the chat.
        </p>
      </div>
    </div>
  );
};

export default ChatWallpaperPicker;
