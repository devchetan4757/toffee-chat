import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Load .env from backend/ (one level up from src/) regardless of the
// directory the process was launched from — dotenv.config() with no
// path only checks process.cwd(), which broke when running from src/.
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, "../.env") });

import uploadRoutes from "./routes/upload.routes.js";
import galleryRoutes from "./routes/gallery.routes.js";
import musicRoutes from "./routes/music.routes.js";
import express from "express";
import cookieParser from "cookie-parser";
import cors from "cors";

import { app, server } from "./lib/socket.js";
import { connectDB } from "./lib/db.js";

import authRoutes from "./routes/auth.route.js";
import messageRoutes from "./routes/message.route.js";

const PORT = process.env.PORT || 5000;

// Safety net against transient network errors (e.g. mobile data/wifi
// blips on Termux causing MongoDB ECONNRESET) taking down the whole
// server. db.js now listens for connection-level errors specifically,
// but this catches anything else that slips through as a last resort —
// log it and keep running instead of crashing.
process.on("unhandledRejection", (reason) => {
  console.error("Unhandled Rejection (server kept running):", reason);
});
process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception (server kept running):", err);
});

// Middleware
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cookieParser());
app.use(
  cors({
    origin: process.env.NODE_ENV === "development"
      ? ["http://localhost:5173", "http://127.0.0.1:5173"]
      : true, // allow same-origin in production
    credentials: true,
  })
);

console.log("USER1_PASSWORD loaded");
console.log("USER2_PASSWORD loaded");
// Routes
app.use("/api/auth", authRoutes);
app.use("/api/messages", messageRoutes);
app.use("/api/upload", uploadRoutes);
app.use("/api/gallery", galleryRoutes);
app.use("/api/music", musicRoutes);

// Production build serving
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../../frontend/dist")));

  app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "../../frontend/dist/index.html"));
  });
}

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res
    .status(err.status || 500)
    .json({ message: err.message || "Internal Server Error" });
});

// Connect DB first, then start server
connectDB().then(() => {
  server.listen(PORT, () => {
    console.log(`Server running on PORT: ${PORT}`);
  });
});
